<template>
  <div class="mb-2 input-component">
    <label>
      <span class="font-bold text-gray-600">
        Username
      </span>
      <input
        class="block w-full px-2 py-1 text-xl border border-red-500 focus:outline-none"
      />
      <p class="text-red-500 ">some error</p>
    </label>
  </div>
</template>
