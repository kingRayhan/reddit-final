<template>
  <form
    class="flex flex-col items-end p-2 mb-3 border border-gray-600 justify-items-end"
  >
    <div class="flex">
      <input
        type="text"
        placeholder="Email"
        class="w-1/2 px-3 py-1 mr-3 border border-gray-600 focus:outline-none focus:border-primaryDark"
      />
      <input
        type="password"
        placeholder="Password"
        class="w-1/2 px-3 py-1 border border-gray-600 focus:outline-none focus:border-primaryDark"
      />
    </div>
    <div>
      <a href="#">Forgot password?</a>
      <button class="px-3 mt-2 bg-gray-200 border border-gray-600 ">
        Login
      </button>
    </div>
  </form>
</template>
