<template>
  <div>
    <h3 class="text-2xl">Quick Rules:</h3>
    <ul>
      <li>
        Do not post shallow content. All posts must be directly book related,
        informative, and discussion focused.
      </li>
      <li>
        Please use a civil tone and assume good faith when entering a
        conversation.
      </li>
      <li>
        We love original content and self-posts! Thoughts, discussion questions,
        epiphanies and interesting links about authors and their work. We also
        encourage discussion about developments in the book world and we have a
        flair system.
      </li>
      <li>
        We don't allow personal recommendation posts. You can ask in our Weekly
        Recommendation Thread, consult our Suggested Reading or What to Read
        page, or post in /r/suggestmeabook.
      </li>
    </ul>
  </div>
</template>

<style scoped>
div {
  margin-top: 25px;
}
ul li {
  margin-bottom: 15px;
}
</style>
