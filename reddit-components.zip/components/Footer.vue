<template>
  <footer class="text-sm text-gray-600">
    <img
      src="~/static/images/reddit-flying-with-ballons.jpg"
      alt="reddit-cute"
    />

    <p>
      Use of this site constitutes acceptance of our
      <a href="https://old.reddit.com/help/useragreement">User Agreement</a> and
      <a href="https://old.reddit.com/help/privacypolicy">Privacy Policy</a>. ©
      2020 reddit inc. All rights reserved.
    </p>
    <p class="bottommenu">
      REDDIT and the ALIEN Logo are registered trademarks of reddit inc.
    </p>
  </footer>
</template>

<style lang="scss" scoped>
footer {
  text-align: center;
  padding: 25px 0;
  img {
    margin: auto;
    padding: 25px 0;
  }
}
</style>
